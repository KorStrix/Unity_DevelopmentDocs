﻿#region Header
/*	============================================
 *	Aurthor 			  : Strix
 *	Initial Creation Date : $time$
 *	Summary 			  : 
 *  Template 		      : Visual Studio ItemTemplate For Unity V7
   ============================================ */
#endregion Header

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// 
/// </summary>
public class #SCRIPTNAME#
{
    /* const & readonly declaration             */

	/* enum & struct declaration                */

    /* public - Field declaration            	*/


    /* protected & private - Field declaration  */


    // ========================================================================== //

	/* public - [Do~Somthing] Function 	        */


	// ========================================================================== //

    /* protected - [Override & Unity API]       */
    

    /* protected - [abstract & virtual]         */


    // ========================================================================== //

    #region Private
    
    #endregion Private
}